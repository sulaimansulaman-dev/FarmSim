class_name SaveLevelDataComponent
extends Node

var level_scene_name: String
var save_game_data_path: String = 'user://game_data/'
var save_file_name: String = 'save_%s_game_data.tres'
var game_data_resource: SaveGameDataResource


func _ready() -> void:
    add_to_group('save_level_data_component')
    # Keyed by the level id rather than the scene's root node name. Stages 2-5
    # were built from the Island 1 scene, and a shared root name would let one
    # stage's save load into another.
    level_scene_name = SceneManager.current_level if not SceneManager.current_level.is_empty() else str(get_parent().name)


func save_node_data() -> void:
    game_data_resource = SaveGameDataResource.new()

    var nodes = get_tree().get_nodes_in_group('save_data_component')
    for node: SaveDataComponent in nodes:
        if node is not SaveDataComponent:
            continue

        var save_data_resource: NodeDataResource = node._save_data()
        var save_final_resource = save_data_resource.duplicate()
        game_data_resource.save_data_nodes.append(save_final_resource)


func save_game() -> void:
    if !DirAccess.dir_exists_absolute(save_game_data_path):
        DirAccess.make_dir_absolute(save_game_data_path)

    var level_save_file_name: String = save_file_name % level_scene_name
    save_node_data()
    var result: int = ResourceSaver.save(game_data_resource, save_game_data_path + level_save_file_name)
    print('Save result: ', result)


func load_game() -> void:
    var level_save_file_name: String = save_file_name % level_scene_name
    var save_game_path: String = save_game_data_path + level_save_file_name

    if not FileAccess.file_exists(save_game_path):
        return

    game_data_resource = ResourceLoader.load(save_game_path)
    if game_data_resource == null:
        return

    var root_node: Window = get_tree().root

    for resource in game_data_resource.save_data_nodes:
        if resource is NodeDataResource:
            resource._load_data(root_node)
