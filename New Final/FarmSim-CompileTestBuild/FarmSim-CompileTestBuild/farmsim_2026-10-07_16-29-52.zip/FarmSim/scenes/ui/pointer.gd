extends Control

## Target node to point towards (your StageGate node)
@export var target_node: Node2D

## Margin from the screen edge in pixels
@export var margin: float = 32.0

@onready var arrow_sprite: Sprite2D = $Sprite2D


func _process(_delta: float) -> void:
	if target_node == null or not is_instance_valid(target_node):
		hide()
		return

	var camera := get_viewport().get_camera_2d()
	if camera == null:
		hide()
		return
	if arrow_sprite == null:
			return
	var viewport_rect := get_viewport_rect()
	var screen_center := viewport_rect.size * 0.5

	# Convert target's global world position to screen space coordinates
	var target_screen_pos := target_node.get_global_transform_with_canvas().origin

	# Check if the target is currently within the visible screen area
	var is_on_screen := viewport_rect.grow(-margin).has_point(target_screen_pos)

	if is_on_screen:
		# Hide indicator when the bridge is visible on screen
		hide()
	else:
		show()

		# Clamp indicator position to the right edge of the screen
		var clamped_y := clampf(target_screen_pos.y, margin, viewport_rect.size.y - margin)
		global_position = Vector2(viewport_rect.size.x - margin, clamped_y)

		# Rotate the arrow towards the target's vertical position
		var angle := (target_screen_pos - global_position).angle()
		arrow_sprite.rotation = angle
